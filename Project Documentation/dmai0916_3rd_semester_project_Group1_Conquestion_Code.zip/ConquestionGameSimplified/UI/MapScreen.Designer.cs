﻿namespace UI
{
    partial class MapScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.MapNode_1 = new System.Windows.Forms.Button();
            this.MapNode_2 = new System.Windows.Forms.Button();
            this.MapNode_3 = new System.Windows.Forms.Button();
            this.MapNode_4 = new System.Windows.Forms.Button();
            this.MapNode_5 = new System.Windows.Forms.Button();
            this.MapNode_6 = new System.Windows.Forms.Button();
            this.MapNode_7 = new System.Windows.Forms.Button();
            this.MapNode_8 = new System.Windows.Forms.Button();
            this.MapNode_10 = new System.Windows.Forms.Button();
            this.MapNode_9 = new System.Windows.Forms.Button();
            this.MapNode_11 = new System.Windows.Forms.Button();
            this.MapNode_12 = new System.Windows.Forms.Button();
            this.MapNode_13 = new System.Windows.Forms.Button();
            this.MapNode_14 = new System.Windows.Forms.Button();
            this.MapNode_15 = new System.Windows.Forms.Button();
            this.MapNode_16 = new System.Windows.Forms.Button();
            this.PlayerLabel1 = new System.Windows.Forms.Label();
            this.PlayerLabel2 = new System.Windows.Forms.Label();
            this.PlayerLabel3 = new System.Windows.Forms.Label();
            this.PlayerLabel4 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.StatusMessage = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // MapNode_1
            // 
            this.MapNode_1.Location = new System.Drawing.Point(18, 23);
            this.MapNode_1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.MapNode_1.Name = "MapNode_1";
            this.MapNode_1.Size = new System.Drawing.Size(53, 57);
            this.MapNode_1.TabIndex = 0;
            this.MapNode_1.Text = "1";
            this.MapNode_1.UseVisualStyleBackColor = true;
            this.MapNode_1.Click += new System.EventHandler(this.MapNode_1_Click);
            // 
            // MapNode_2
            // 
            this.MapNode_2.Location = new System.Drawing.Point(70, 23);
            this.MapNode_2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.MapNode_2.Name = "MapNode_2";
            this.MapNode_2.Size = new System.Drawing.Size(53, 57);
            this.MapNode_2.TabIndex = 1;
            this.MapNode_2.Text = "2";
            this.MapNode_2.UseVisualStyleBackColor = true;
            this.MapNode_2.Click += new System.EventHandler(this.MapNode_2_Click);
            // 
            // MapNode_3
            // 
            this.MapNode_3.Location = new System.Drawing.Point(121, 23);
            this.MapNode_3.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.MapNode_3.Name = "MapNode_3";
            this.MapNode_3.Size = new System.Drawing.Size(53, 57);
            this.MapNode_3.TabIndex = 2;
            this.MapNode_3.Text = "3";
            this.MapNode_3.UseVisualStyleBackColor = true;
            this.MapNode_3.Click += new System.EventHandler(this.MapNode_3_Click);
            // 
            // MapNode_4
            // 
            this.MapNode_4.Location = new System.Drawing.Point(173, 23);
            this.MapNode_4.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.MapNode_4.Name = "MapNode_4";
            this.MapNode_4.Size = new System.Drawing.Size(53, 57);
            this.MapNode_4.TabIndex = 3;
            this.MapNode_4.Text = "4";
            this.MapNode_4.UseVisualStyleBackColor = true;
            this.MapNode_4.Click += new System.EventHandler(this.MapNode_4_Click);
            // 
            // MapNode_5
            // 
            this.MapNode_5.Location = new System.Drawing.Point(18, 79);
            this.MapNode_5.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.MapNode_5.Name = "MapNode_5";
            this.MapNode_5.Size = new System.Drawing.Size(53, 57);
            this.MapNode_5.TabIndex = 4;
            this.MapNode_5.Text = "5";
            this.MapNode_5.UseVisualStyleBackColor = true;
            this.MapNode_5.Click += new System.EventHandler(this.MapNode_5_Click);
            // 
            // MapNode_6
            // 
            this.MapNode_6.Location = new System.Drawing.Point(70, 79);
            this.MapNode_6.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.MapNode_6.Name = "MapNode_6";
            this.MapNode_6.Size = new System.Drawing.Size(53, 57);
            this.MapNode_6.TabIndex = 5;
            this.MapNode_6.Text = "6";
            this.MapNode_6.UseVisualStyleBackColor = true;
            this.MapNode_6.Click += new System.EventHandler(this.MapNode_6_Click);
            // 
            // MapNode_7
            // 
            this.MapNode_7.Location = new System.Drawing.Point(121, 79);
            this.MapNode_7.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.MapNode_7.Name = "MapNode_7";
            this.MapNode_7.Size = new System.Drawing.Size(53, 57);
            this.MapNode_7.TabIndex = 6;
            this.MapNode_7.Text = "7";
            this.MapNode_7.UseVisualStyleBackColor = true;
            this.MapNode_7.Click += new System.EventHandler(this.MapNode_7_Click);
            // 
            // MapNode_8
            // 
            this.MapNode_8.Location = new System.Drawing.Point(173, 79);
            this.MapNode_8.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.MapNode_8.Name = "MapNode_8";
            this.MapNode_8.Size = new System.Drawing.Size(53, 57);
            this.MapNode_8.TabIndex = 7;
            this.MapNode_8.Text = "8";
            this.MapNode_8.UseVisualStyleBackColor = true;
            this.MapNode_8.Click += new System.EventHandler(this.MapNode_8_Click);
            // 
            // MapNode_10
            // 
            this.MapNode_10.Location = new System.Drawing.Point(70, 136);
            this.MapNode_10.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.MapNode_10.Name = "MapNode_10";
            this.MapNode_10.Size = new System.Drawing.Size(53, 57);
            this.MapNode_10.TabIndex = 8;
            this.MapNode_10.Text = "10";
            this.MapNode_10.UseVisualStyleBackColor = true;
            this.MapNode_10.Click += new System.EventHandler(this.MapNode_10_Click);
            // 
            // MapNode_9
            // 
            this.MapNode_9.Location = new System.Drawing.Point(18, 136);
            this.MapNode_9.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.MapNode_9.Name = "MapNode_9";
            this.MapNode_9.Size = new System.Drawing.Size(53, 57);
            this.MapNode_9.TabIndex = 9;
            this.MapNode_9.Text = "9";
            this.MapNode_9.UseVisualStyleBackColor = true;
            this.MapNode_9.Click += new System.EventHandler(this.MapNode_9_Click);
            // 
            // MapNode_11
            // 
            this.MapNode_11.Location = new System.Drawing.Point(121, 136);
            this.MapNode_11.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.MapNode_11.Name = "MapNode_11";
            this.MapNode_11.Size = new System.Drawing.Size(53, 57);
            this.MapNode_11.TabIndex = 10;
            this.MapNode_11.Text = "11";
            this.MapNode_11.UseVisualStyleBackColor = true;
            this.MapNode_11.Click += new System.EventHandler(this.MapNode_11_Click);
            // 
            // MapNode_12
            // 
            this.MapNode_12.Location = new System.Drawing.Point(173, 136);
            this.MapNode_12.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.MapNode_12.Name = "MapNode_12";
            this.MapNode_12.Size = new System.Drawing.Size(53, 57);
            this.MapNode_12.TabIndex = 11;
            this.MapNode_12.Text = "12";
            this.MapNode_12.UseVisualStyleBackColor = true;
            this.MapNode_12.Click += new System.EventHandler(this.MapNode_12_Click);
            // 
            // MapNode_13
            // 
            this.MapNode_13.Location = new System.Drawing.Point(18, 192);
            this.MapNode_13.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.MapNode_13.Name = "MapNode_13";
            this.MapNode_13.Size = new System.Drawing.Size(53, 57);
            this.MapNode_13.TabIndex = 12;
            this.MapNode_13.Text = "13";
            this.MapNode_13.UseVisualStyleBackColor = true;
            this.MapNode_13.Click += new System.EventHandler(this.MapNode_13_Click);
            // 
            // MapNode_14
            // 
            this.MapNode_14.Location = new System.Drawing.Point(70, 192);
            this.MapNode_14.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.MapNode_14.Name = "MapNode_14";
            this.MapNode_14.Size = new System.Drawing.Size(53, 57);
            this.MapNode_14.TabIndex = 13;
            this.MapNode_14.Text = "14";
            this.MapNode_14.UseVisualStyleBackColor = true;
            this.MapNode_14.Click += new System.EventHandler(this.MapNode_14_Click);
            // 
            // MapNode_15
            // 
            this.MapNode_15.Location = new System.Drawing.Point(121, 192);
            this.MapNode_15.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.MapNode_15.Name = "MapNode_15";
            this.MapNode_15.Size = new System.Drawing.Size(53, 57);
            this.MapNode_15.TabIndex = 14;
            this.MapNode_15.Text = "15";
            this.MapNode_15.UseVisualStyleBackColor = true;
            this.MapNode_15.Click += new System.EventHandler(this.MapNode_15_Click);
            // 
            // MapNode_16
            // 
            this.MapNode_16.Location = new System.Drawing.Point(173, 192);
            this.MapNode_16.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.MapNode_16.Name = "MapNode_16";
            this.MapNode_16.Size = new System.Drawing.Size(53, 57);
            this.MapNode_16.TabIndex = 15;
            this.MapNode_16.Text = "16";
            this.MapNode_16.UseVisualStyleBackColor = true;
            this.MapNode_16.Click += new System.EventHandler(this.MapNode_16_Click);
            // 
            // PlayerLabel1
            // 
            this.PlayerLabel1.AutoSize = true;
            this.PlayerLabel1.Location = new System.Drawing.Point(301, 34);
            this.PlayerLabel1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.PlayerLabel1.Name = "PlayerLabel1";
            this.PlayerLabel1.Size = new System.Drawing.Size(67, 13);
            this.PlayerLabel1.TabIndex = 16;
            this.PlayerLabel1.Text = "Player Name";
            this.PlayerLabel1.Visible = false;
            // 
            // PlayerLabel2
            // 
            this.PlayerLabel2.AutoSize = true;
            this.PlayerLabel2.Location = new System.Drawing.Point(301, 66);
            this.PlayerLabel2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.PlayerLabel2.Name = "PlayerLabel2";
            this.PlayerLabel2.Size = new System.Drawing.Size(67, 13);
            this.PlayerLabel2.TabIndex = 17;
            this.PlayerLabel2.Text = "Player Name";
            this.PlayerLabel2.Visible = false;
            // 
            // PlayerLabel3
            // 
            this.PlayerLabel3.AutoSize = true;
            this.PlayerLabel3.Location = new System.Drawing.Point(301, 101);
            this.PlayerLabel3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.PlayerLabel3.Name = "PlayerLabel3";
            this.PlayerLabel3.Size = new System.Drawing.Size(67, 13);
            this.PlayerLabel3.TabIndex = 18;
            this.PlayerLabel3.Text = "Player Name";
            this.PlayerLabel3.Visible = false;
            // 
            // PlayerLabel4
            // 
            this.PlayerLabel4.AutoSize = true;
            this.PlayerLabel4.Location = new System.Drawing.Point(301, 136);
            this.PlayerLabel4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.PlayerLabel4.Name = "PlayerLabel4";
            this.PlayerLabel4.Size = new System.Drawing.Size(67, 13);
            this.PlayerLabel4.TabIndex = 19;
            this.PlayerLabel4.Text = "Player Name";
            this.PlayerLabel4.Visible = false;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // StatusMessage
            // 
            this.StatusMessage.AutoSize = true;
            this.StatusMessage.Location = new System.Drawing.Point(301, 180);
            this.StatusMessage.Name = "StatusMessage";
            this.StatusMessage.Size = new System.Drawing.Size(93, 13);
            this.StatusMessage.TabIndex = 20;
            this.StatusMessage.Text = "status placeholder";
            this.StatusMessage.Visible = false;
            // 
            // MapScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(460, 318);
            this.Controls.Add(this.StatusMessage);
            this.Controls.Add(this.PlayerLabel4);
            this.Controls.Add(this.PlayerLabel3);
            this.Controls.Add(this.PlayerLabel2);
            this.Controls.Add(this.PlayerLabel1);
            this.Controls.Add(this.MapNode_16);
            this.Controls.Add(this.MapNode_15);
            this.Controls.Add(this.MapNode_14);
            this.Controls.Add(this.MapNode_13);
            this.Controls.Add(this.MapNode_12);
            this.Controls.Add(this.MapNode_11);
            this.Controls.Add(this.MapNode_9);
            this.Controls.Add(this.MapNode_10);
            this.Controls.Add(this.MapNode_8);
            this.Controls.Add(this.MapNode_7);
            this.Controls.Add(this.MapNode_6);
            this.Controls.Add(this.MapNode_5);
            this.Controls.Add(this.MapNode_4);
            this.Controls.Add(this.MapNode_3);
            this.Controls.Add(this.MapNode_2);
            this.Controls.Add(this.MapNode_1);
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Name = "MapScreen";
            this.Text = "MapScreen";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MapScreen_Closing);
            this.Load += new System.EventHandler(this.MapScreen_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button MapNode_1;
        private System.Windows.Forms.Button MapNode_2;
        private System.Windows.Forms.Button MapNode_3;
        private System.Windows.Forms.Button MapNode_4;
        private System.Windows.Forms.Button MapNode_5;
        private System.Windows.Forms.Button MapNode_6;
        private System.Windows.Forms.Button MapNode_7;
        private System.Windows.Forms.Button MapNode_8;
        private System.Windows.Forms.Button MapNode_10;
        private System.Windows.Forms.Button MapNode_9;
        private System.Windows.Forms.Button MapNode_11;
        private System.Windows.Forms.Button MapNode_12;
        private System.Windows.Forms.Button MapNode_13;
        private System.Windows.Forms.Button MapNode_14;
        private System.Windows.Forms.Button MapNode_15;
        private System.Windows.Forms.Button MapNode_16;
        private System.Windows.Forms.Label PlayerLabel1;
        private System.Windows.Forms.Label PlayerLabel2;
        private System.Windows.Forms.Label PlayerLabel3;
        private System.Windows.Forms.Label PlayerLabel4;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label StatusMessage;
    }
}