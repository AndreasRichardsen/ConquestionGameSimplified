﻿$(document).ready(function () {
    $("#correctP").css("background-color", "#32cd32");
    $(".incorrectP").css("background-color", "red");
});